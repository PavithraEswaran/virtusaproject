package com.virtusa.services;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.springframework.beans.factory.annotation.Autowired;

import com.virtusa.dao.EmployeeDAO;
import com.virtusa.model.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDAO edao;
	private SessionFactory sessionFactory;
	Session session = this.sessionFactory.openSession();
	Transaction tx = session.beginTransaction();
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    
	public void save(Employee e) {
		
		
		session.persist(e);
		tx.commit();
		session.close();
	}

	@SuppressWarnings("unchecked")
	public List<Employee> list() {
		
		List<Employee> personList = session.createQuery("from Employee").list();
		session.close();
		return personList;
	}

	public void delete(Employee e) {
		// TODO Auto-generated method stub
		session.delete(e);
		tx.commit();
		session.close();
	}

	



}
