package snippet;

public class Snippet {
	mvn eclipse:eclipse -Dwtpversion=2.0
}

