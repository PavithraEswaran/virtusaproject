package com.virtusa.vforum.testing;



import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.Assert;
import org.junit.Test;

import com.virtusa.vforum.DAO.EditQuestionDAO;
import com.virtusa.vforum.models.Category;
import com.virtusa.vforum.models.Employee;
import com.virtusa.vforum.models.Questions;

public class EditQuestionJunit {

	@Test
	public void test() {
		EditQuestionDAO eqdao=new EditQuestionDAO();
		int count=eqdao.updateQuestion("hello answer,.",64);
	    Assert.assertEquals(1,count);
	}

}
