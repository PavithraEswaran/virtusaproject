package com.dao;

public class StudentImpl implements StudentDAO {

	public void add() {
		// TODO Auto-generated method stub
	  	

	}

	public void delete() {
		// TODO Auto-generated method stub

	}

}
