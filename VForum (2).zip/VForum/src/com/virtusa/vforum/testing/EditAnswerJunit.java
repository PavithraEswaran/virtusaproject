package com.virtusa.vforum.testing;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.virtusa.vforum.DAO.EditAnswerDAO;
import com.virtusa.vforum.DAO.EditQuestionDAO;

public class EditAnswerJunit {

	@Test
	public void test() {
		EditAnswerDAO eadao=new EditAnswerDAO();
		int count=eadao.updateAnswer(" Depends upon the project.,",53);
	    Assert.assertEquals(1,count);
	}

}
