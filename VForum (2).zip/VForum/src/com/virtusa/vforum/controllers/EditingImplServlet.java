package com.virtusa.vforum.controllers;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.vforum.DAO.EditQuestionDAO;
import com.virtusa.vforum.DAO.QuestionDAO;

/**
 * Servlet implementation class EditingImplServlet
 */
public class EditingImplServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
      
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        int postId=Integer.parseInt(request.getParameter("id"));
        String desc=request.getParameter("desc");
        HttpSession session= request.getSession(false);
    	int emp_id=(int) session.getAttribute("id");
//    	QuestionDAO qdao=new QuestionDAO();
//    	int Ques_empid=qdao.getEmployeeByQues(postId);
//    	if(emp_id==Ques_empid)
//    	{
    		EditQuestionDAO edao=new EditQuestionDAO();
    		edao.updateQuestion(desc, postId);
    		
//    	}
//    	else
//    	{
//    		out.println("This question is not posted by you.So you can't update it...");
//    	}
    	RequestDispatcher rd=request.getRequestDispatcher("MyQuestionsServlet");
		rd.forward(request, response);
	}

}
