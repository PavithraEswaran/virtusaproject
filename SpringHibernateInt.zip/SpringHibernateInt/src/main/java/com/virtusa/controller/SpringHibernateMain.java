package com.virtusa.controller;

import org.springframework.context.support.ClassPathXmlApplicationContext;


import com.virtusa.dao.EmployeeDAO;
import com.virtusa.model.Employee;

public class SpringHibernateMain {

	public static void main(String[] args) {

		ClassPathXmlApplicationContext context = new ClassPathXmlApplicationContext("spring-servlet.xml");
		
		EmployeeDAO edao = context.getBean(EmployeeDAO.class);
		
		Employee emp = new Employee();
		emp.setName("ABC");
		emp.setCountry("India");
		
		edao.save(emp);
		
		System.out.println("Emplopyee:"+emp);
		edao.delete(emp);
//		
//	List<Employee> list = edao.list();
//		
//		for(Employee p : list){
//			System.out.println("Person List::"+p);
//		}
//		
		context.close();
		
	}

}
