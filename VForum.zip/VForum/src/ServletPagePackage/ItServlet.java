package ServletPagePackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import DAOClasses.AnswerDAO;
import DAOClasses.CategoryDAO;
import DAOClasses.EmployeeDAO;
import DAOClasses.QuestionDAO;
import EntityClassesPackage.Answers;
import EntityClassesPackage.Category;
import EntityClassesPackage.Employee;
import EntityClassesPackage.Questions;

/**
 * Servlet implementation class ItServlet
 */
public class ItServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
   
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        out.println("<a href='ItPage.html'>Click here to add question</a>");
        out.println("<br><br>");
        String question=request.getParameter("question");
        CategoryDAO cdao=new CategoryDAO();
        Category c=cdao.getCategory("IT");
       
        QuestionDAO qdao=new QuestionDAO();
        
        AnswerDAO adao=new AnswerDAO();
        HashMap<Integer,Questions>hmap= qdao.getQuestions(c);
        ArrayList<Answers> list=new ArrayList<Answers>();
        for(Entry<Integer, Questions> e:hmap.entrySet())
        {
        	System.out.println(e.getKey()+" "+e.getValue().getQuesDesc());
        	out.println("<h3>"+e.getValue().getQuesDesc()+"<br/>"+e.getValue().getEmployee().getEmp_name()+" "
        			+e.getValue().getEmployee().getEmp_Designation()+e.getValue().getDate()+"<br/></h3>");
        	list=adao.getAnswers(e.getKey());
        	if(list.size()==0)
        	{
        		out.println("No Answers<br><br>");
        		
        	}
        	else
        	{
	        	for(Answers ans:list)
	        	{
	        		out.println("<h3>"+ans.getAnswer_desc()+"<br/>"+ans.getEmp().getEmp_name()+" "
	            			+ans.getEmp().getEmp_Designation()+ans.getDate()+"<br/></h3>");
	        		out.println("<br>");
	        	}
	        	
            
        	}
        	int a=8;
        	System.out.println(e.getKey()+"aaa");
        	out.println("<form action='AddAnswer' method='post'>");
       	 out.println("<input type='hidden' name='postId' value="+a+"><br/>"
       	 		+ "Click here to add question"+e.getKey()+"</a>");
       	 out.println("<input type='submit' value='Add Answer'>");
       	System.out.println(e.getKey()+"aaa");
        }
        	
//        RequestDispatcher dispatcher=request.getRequestDispatcher("ItPage.html");
//        dispatcher.include(request, response);
        
        
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}
}
