package com.virtusa.dao;

import java.util.List;

import com.virtusa.models.Employee;

public interface EmployeeDAO {
    public void save(Employee e);
	
	public void delete(Employee e);
	
	
}
