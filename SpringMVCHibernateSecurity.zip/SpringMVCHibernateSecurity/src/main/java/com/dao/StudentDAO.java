package com.dao;

public interface StudentDAO {
  void add(student);
  void delete(student);
}
