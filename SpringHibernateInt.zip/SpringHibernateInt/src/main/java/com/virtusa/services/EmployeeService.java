package com.virtusa.services;

import java.util.List;

import com.virtusa.model.Employee;

public interface EmployeeService {
public void save(Employee e);
public void delete(Employee e);
//public List<Employee> list();
	
	
}
