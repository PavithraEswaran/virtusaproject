package ServletPagePackage;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import DAOClasses.AnswerDAO;
import DAOClasses.QuestionDAO;
import EntityClassesPackage.Answers;
import EntityClassesPackage.Questions;

/**
 * Servlet implementation class HomeServlet
 */
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        AnswerDAO adao=new AnswerDAO();
        QuestionDAO qdao=new QuestionDAO();
        HashMap<Integer,Questions>hmap= qdao.getAllQuestions();
        ArrayList<Answers> list=new ArrayList<Answers>();
        for(Entry<Integer, Questions> e:hmap.entrySet())
        {
        	out.println(e.getValue().getQuesDesc()+"<br/>"+e.getValue().getEmployee().getEmp_name()+
        			e.getValue().getEmployee().getEmp_Designation());
        	list=adao.getAnswers(e.getKey());
        	if(list==null)
        	{
        		out.println("No Answers");
        	}
        	else
        	{
        	for(Answers ans:list)
        	{
        		out.println(ans);
        	}
        	}
	}
        RequestDispatcher dispatcher=request.getRequestDispatcher("right.html");
        dispatcher.include(request, response);
}
	
}
