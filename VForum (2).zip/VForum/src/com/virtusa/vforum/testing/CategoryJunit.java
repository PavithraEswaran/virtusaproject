package com.virtusa.vforum.testing;



import org.junit.Assert;
import org.junit.Test;

import com.virtusa.vforum.DAO.CategoryDAO;
import com.virtusa.vforum.models.Category;

public class CategoryJunit {

	@Test
	public void test() {
		CategoryDAO cdao=new CategoryDAO();
		Category catTruecheck=new Category(11,"IT");
		Category catTrue=cdao.getCategory("IT");
		Category catFalse=cdao.getCategory("SECURITY");
		Assert.assertEquals(catTruecheck.getCate_name(),catTrue.getCate_name());
		Assert.assertEquals(catTruecheck.getCatId(),catTrue.getCatId());
		Assert.assertEquals(null,catFalse);
	}
	@Test
	public void test1() {
		CategoryDAO cdao=new CategoryDAO();
		Category catTruecheck=new Category(11,"IT");
		Category catTrue=cdao.getCategoryById(11);
		Category catFalse=cdao.getCategoryById(66);
		Assert.assertEquals(catTruecheck.getCate_name(),catTrue.getCate_name());
		Assert.assertEquals(catTruecheck.getCatId(),catTrue.getCatId());
		Assert.assertEquals(null,catFalse);
	}

}
