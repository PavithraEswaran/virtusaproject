package com.virtusa.controller;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;

import com.virtusa.dao.EmployeeDAO;
import com.virtusa.models.Employee;
import com.virtusa.services.EmployeeService;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class EmployeeController {

	@Autowired
	EmployeeService eservice;
	EmployeeDAO edao;
	 @RequestMapping(value = "/register", method = RequestMethod.GET)
	 public ModelAndView showSave(HttpServletRequest request, HttpServletResponse response) {
		    ModelAndView mav = new ModelAndView("register");
		    mav.addObject("save", new Employee());

		    return mav;
		  }
	 @RequestMapping(value = "/savingProcess", method = RequestMethod.POST)
	  public ModelAndView savingProcess(HttpServletRequest request, HttpServletResponse response,
	      @ModelAttribute("save") Employee employee) {
    ModelAndView mav = null;

	   // Employee user = eservice.save(employee);
        edao.save(employee);
	    if (edao != null) {
	      mav = new ModelAndView("welcome");
	      mav.addObject("name", employee.getName());
	    } else {
	      mav = new ModelAndView("register");
	      mav.addObject("message", "Data is wrong!!");
	    }

	    return mav;
	  }
	 @RequestMapping(value = "/delete", method = RequestMethod.GET)
	 public ModelAndView showDeleted(HttpServletRequest request, HttpServletResponse response) {
		    ModelAndView mav = new ModelAndView("delete");
		    mav.addObject("delete", new Employee());

		    return mav;
		  }
	 @RequestMapping(value = "/savingProcess", method = RequestMethod.POST)
	  public ModelAndView deleteProcess(HttpServletRequest request, HttpServletResponse response,
	      @ModelAttribute("delete") Employee employee) {
   ModelAndView mav = null;

	   // Employee user = eservice.save(employee);
       edao.delete(employee);
	    if (edao != null) {
	      mav = new ModelAndView("deletemsg");
	      mav.addObject("message", "Data deleted");
	    } 

	    return mav;
	  }
}
