package com.virtusa.vforum.DAO;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;

import javax.servlet.http.HttpSession;

import com.virtusa.vforum.DBConnection.DBUtils;
import com.virtusa.vforum.models.Category;
import com.virtusa.vforum.models.Employee;
import com.virtusa.vforum.models.Questions;
import com.virtusa.vfroum.queries.SqlQuery;

public class QuestionDAO {
public int addQuestion(Category cat,String question,int empid) throws ParseException{
	String sqlQuery=SqlQuery.addQuestion;  //"insert into Questions(cat_id,question_desc,emp_id,date) values(?,?,?,?)";
	int count=0;
	ArrayList<Questions> qlist=null;
	try(Connection con=DBUtils.buildConnection();
			PreparedStatement pstmt=con.prepareStatement(sqlQuery);)
	{
		
		pstmt.setInt(1,cat.getCatId());
		pstmt.setString(2,question);
		pstmt.setInt(3,empid);
		long milli=System.currentTimeMillis();
		Date date=new Date(milli);
		pstmt.setDate(4,date);
		//index starts from 1 and move rightwards
		count=pstmt.executeUpdate();
		
		
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	} catch (Exception e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return count;
}
HashMap<Integer,Questions> hmap=new HashMap<Integer,Questions>();
public HashMap<Integer,Questions>  getQuestions(Category cat)
{
//	long milli=System.currentTimeMillis();
//	Date curdate=new Date(milli);
	String sqlQuery=SqlQuery.getQuestions  ;  //"select * from Questions where cat_id=?  order by ques_id";
	try(Connection con=DBUtils.buildConnection();
			PreparedStatement pstmt=con.prepareStatement(sqlQuery);)
	{
	 pstmt.setInt(1, cat.getCatId());
	// pstmt.setDate(2, curdate);
	 ResultSet rs=pstmt.executeQuery();
	 while(rs.next())
	 {
		 int c_id=rs.getInt(2);
		 int q_id=rs.getInt(1);
		 String desc=rs.getString(3);
		 Date date=rs.getDate(5);
		 int emp_id=rs.getInt(4);
		 EmployeeDAO eDao=new EmployeeDAO();
		 Employee employee=eDao.getEmployee(emp_id);
		 Questions ques=new Questions(cat,desc,employee,date);
		 hmap.put(q_id, ques);
		 
	 }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return hmap;
}

HashMap<Integer,Questions> qmap=new HashMap<Integer,Questions>();
public HashMap<Integer,Questions>  getAllQuestions()
{
//	long milli=System.currentTimeMillis();
//	Date curdate=new Date(milli);
	String sqlQuery=SqlQuery.getAllQuestions;//"select * from Questions order by ques_id";
	try(Connection con=DBUtils.buildConnection();
			PreparedStatement pstmt=con.prepareStatement(sqlQuery);)
	{
		//pstmt.setDate(1, curdate); 
	 ResultSet rs=pstmt.executeQuery();
	 
	 while(rs.next())
	 {
		 int c_id=rs.getInt(2);
		 int q_id=rs.getInt(1);
		 String desc=rs.getString(3);
		 Date date=rs.getDate(5);
		 int emp_id=rs.getInt(4);
		 CategoryDAO cdao=new CategoryDAO();
		 Category cat=cdao.getCategoryById(c_id);
		 EmployeeDAO eDao=new EmployeeDAO();
		 Employee employee=eDao.getEmployee(emp_id);
		 Questions ques=new Questions(cat,desc,employee,date);
		 qmap.put(q_id, ques);
		 
	 }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return qmap;
}

HashMap<Integer,Questions> mqmap=new HashMap<Integer,Questions>();
public HashMap<Integer,Questions>  getMyQuestions(int emp_id){
	String sqlQuery=SqlQuery.getMyQuestions;//"select * from Questions where emp_id=?";
	try(Connection con=DBUtils.buildConnection();
			PreparedStatement pstmt=con.prepareStatement(sqlQuery);)
	{
		pstmt.setInt(1,emp_id);
	 ResultSet rs=pstmt.executeQuery();
	 while(rs.next())
	 {
		 int c_id=rs.getInt(2);
		 int q_id=rs.getInt(1);
		 String desc=rs.getString(3);
		 Date date=rs.getDate(5);
		 int emp_id1=rs.getInt(4);
		 CategoryDAO cdao=new CategoryDAO();
		 Category cat=cdao.getCategoryById(c_id);
		 EmployeeDAO eDao=new EmployeeDAO();
		 Employee employee=eDao.getEmployee(emp_id1);
		 Questions ques=new Questions(cat,desc,employee,date);
		 mqmap.put(q_id, ques);
		 
	 }
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return mqmap;
}
public Questions getQuestionByAnsId(int ans_id){
	String sqlQuery=SqlQuery.getQuestionByAnsId;//"select * from Questions where ques_id=?";
	Questions ques=null;
	try(Connection con=DBUtils.buildConnection();
			PreparedStatement pstmt=con.prepareStatement(sqlQuery);)
	{
		pstmt.setInt(1,ans_id);
	 ResultSet rs=pstmt.executeQuery();
	 
	 while(rs.next())
	 {
		 int c_id=rs.getInt(2);
		 int q_id=rs.getInt(1);
		 String desc=rs.getString(3);
		 Date date=rs.getDate(5);
		 int emp_id1=rs.getInt(4);
		 CategoryDAO cdao=new CategoryDAO();
		 Category cat=cdao.getCategoryById(c_id);
		 EmployeeDAO eDao=new EmployeeDAO();
		 Employee employee=eDao.getEmployee(emp_id1);
		  ques=new Questions(cat,desc,employee,date);
	
	 }
	}	 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 return ques;

}
public int getEmployeeByQues(int ques_id){
	String sqlQuery=SqlQuery.getEmployeeByQues;//"select emp_id from Questions where ques_id=?";
	int e_id=0;
	try(Connection con=DBUtils.buildConnection();
			PreparedStatement pstmt=con.prepareStatement(sqlQuery);)
	{
		pstmt.setInt(1,ques_id);
	 ResultSet rs=pstmt.executeQuery();
	 
	 while(rs.next())
	 {
		 e_id=rs.getInt(1);
	 }
	}	 catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	 return e_id;

}
public int deleteQuestionById(int qId)
{
	String sqlQuery=SqlQuery.deleteQuestionById;//"delete from Questions where Ques_id=?";
	int a=0;
	try(Connection con=DBUtils.buildConnection();
			PreparedStatement pstmt=con.prepareStatement(sqlQuery);)
	{
		 pstmt.setInt(1, qId);
		a=pstmt.executeUpdate();
	 
	} catch (SQLException e) {
		// TODO Auto-generated catch block
		e.printStackTrace();
	}
	return a;
}
}

