package com.virtusa.vfroum.queries;

public final  class SqlQuery {
	//Registration page
 public static final String EmployeeIdCheck="Select * from employee where emp_id= ?"; 
 public static final String UserNameCheck="Select * from employee where user_name= ?";
 public static final String register="insert into employee values(?,?,?,?,?,?)";
 //QuestionDAO
 public static final String addQuestion="insert into Questions(cat_id,question_desc,emp_id,date) values(?,?,?,?)";
 public static final String getQuestions="select * from Questions where cat_id=? and datediff(curDate(),date)<=2 order by date";
 public static final String getAllQuestions="select * from Questions where datediff(curDate(),date)<=2 order by date";
 public static final String getMyQuestions="select * from Questions where emp_id=?";
 public static final String getQuestionByAnsId="select * from Questions where ques_id=?";
 public static final String getEmployeeByQues="select emp_id from Questions where ques_id=?";
 public static final String deleteQuestionById="delete from Questions where Ques_id=?";
 //EmployeeDAO
 public static final String getEmployee="Select * from employee where emp_id= ?";
 //EditQuestionDAO
 public static final String updateQuestion="update questions set question_desc=? where ques_id=?";
 //EditAnswerDAO
 public static final String updateAnswer="update answers set answer_desc=? where ans_id=?";
 //CategoryDAO
 public static final String getCategory="Select * from category where cate_name= ?";
 //AnswerDAO
 public static final String getAnswers="select * from answers where ans_id=?";
 public static final String addAnswer="insert into answers values(?,?,?,?)";
 public static final String getMyAnswers="select * from answers where emp_id=?";
 public static final String deleteAnswerById="delete from Answers where ans_id=?";
 public static final String deleteAnswerById1="delete from Answers where ans_id=? and emp_id=?";
}
