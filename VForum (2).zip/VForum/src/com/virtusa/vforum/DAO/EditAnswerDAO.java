package com.virtusa.vforum.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import com.virtusa.vforum.DBConnection.DBUtils;
import com.virtusa.vfroum.queries.SqlQuery;

public class EditAnswerDAO {
	public int updateAnswer(String newAnswer,int ansid){
		int count=0;
		 String sqlQuery=SqlQuery.updateAnswer;//"update answers set answer_desc=? where ans_id=?";
		 try(Connection con=DBUtils.buildConnection();
					PreparedStatement pstmt=con.prepareStatement(sqlQuery);)
			{
			 pstmt.setString(1,newAnswer);
			 pstmt.setInt(2,ansid);
			  count=pstmt.executeUpdate();
			 
		 
				} catch (SQLException e) {
	// TODO Auto-generated catch block
						e.printStackTrace();
				}
		 return count;
	}
}
