package com.virtusa.dao;

import com.virtusa.models.Student;

public interface StudentDAO {
	
//	void addStudent(Student student);
	void deletestudent(int rollno);

}
