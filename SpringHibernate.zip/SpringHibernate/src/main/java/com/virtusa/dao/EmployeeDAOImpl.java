package com.virtusa.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.models.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {
	private SessionFactory sessionFactory;
	Session session = this.sessionFactory.openSession();
	Transaction tx = session.beginTransaction();
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
	public void save(Employee e) {
		// TODO Auto-generated method stub
		
		session.persist(e);
		tx.commit();
		session.close();

	}

	public void delete(Employee e) {
		// TODO Auto-generated method stub
		session.delete(e);
		tx.commit();
		session.close();
	}
//	public List<Employee> list() {
//		// TODO Auto-generated method stub
//		List<Employee> employeeList = session.createQuery("from Employee").list();
//		session.close();
//		return employeeList;
//	}

}
