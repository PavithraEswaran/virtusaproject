package com.virtusa.vforum.testing;

import static org.junit.Assert.*;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

import com.virtusa.vforum.DAO.QuestionDAO;
import com.virtusa.vforum.models.Category;
import com.virtusa.vforum.models.Employee;
import com.virtusa.vforum.models.Questions;

public class QuestionJunit {
  int count;
  Category c=null;
  QuestionDAO qdao=new QuestionDAO();
  HashMap<Integer,Questions> hmap=new HashMap<Integer,Questions>();
	@Before
	public void before(){
		c=new Category(11,"IT");
		try {
			count=qdao.addQuestion(c, "Which was the first it company started in india?", 8063692);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		hmap=qdao.getQuestions(c);
	}
	@Test
	public void test() {
		Assert.assertEquals(1,count);
	}
	@Test
	public void test1() {
		Date  date = null;
		try {
			 date= new SimpleDateFormat("yyyy-MM-dd").parse("2019-08-02");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		System.out.println(hmap.get(60).getQuesDesc());
		Assert.assertEquals("What kind of functions will be held on Virtusa?",hmap.get(60).getQuesDesc());
		Assert.assertEquals(44,hmap.get(60).getCategory().getCatId());
		Assert.assertEquals(8063703,hmap.get(60).getEmployee().getEmp_id());
		Assert.assertEquals(date,hmap.get(60).getDate());
		}

} 