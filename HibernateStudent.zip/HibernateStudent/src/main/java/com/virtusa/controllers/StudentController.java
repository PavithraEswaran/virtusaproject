package com.virtusa.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpRequest;

import com.virtusa.dao.StudentDAO;
import com.virtusa.models.Student;

import jbr.springmvc.controller.HttpServletRequest;
import jbr.springmvc.controller.HttpServletResponse;
import jbr.springmvc.controller.ModelAndView;
import jbr.springmvc.controller.RequestMapping;
import jbr.springmvc.model.Login;

public class StudentController {
	
	@Autowired
	StudentDAO sdao;
	@RequestMapping(value = "/login", method = RequestMethod.GET)
	  public ModelAndView showLogin(HttpRequest request, HttpServletResponse response) {
	    ModelAndView mav = new ModelAndView("login");
	    mav.addObject("login", new Student());

	    return mav;
	  }
}
