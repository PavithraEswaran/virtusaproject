package com.virtusa.dao;

import org.hibernate.Query;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.models.Student;

public class StudentImpl implements StudentDAO {
private SessionFactory sessionFactory;
Session session = this.sessionFactory.getCurrentSession();
Transaction transaction = session.beginTransaction();

	public void setSessionFactory(SessionFactory sf){
		this.sessionFactory = sf;
	}
	public void deletestudent(int rollno) {
		// TODO Auto-generated method stub
		
		 Query query = session.createSQLQuery("delete from Student where rollno = :rollno");
	        query.setParameter(rollno, "rollno");
	        query.executeUpdate();
	    }

//	public void addStudent(Student student) {
//		// TODO Auto-generated method stub
//		Query qry = session.createQuery("insert into Student(rollno,name,marks)"+"select ROLLNO,name,marks ");
//				
//		session.persist(student);
//		
		
	}


