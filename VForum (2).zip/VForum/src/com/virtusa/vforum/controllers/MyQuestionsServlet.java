package com.virtusa.vforum.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.vforum.DAO.AnswerDAO;
import com.virtusa.vforum.DAO.CategoryDAO;
import com.virtusa.vforum.DAO.QuestionDAO;
import com.virtusa.vforum.models.Answers;
import com.virtusa.vforum.models.Questions;

/**
 * Servlet implementation class MyQuestionsServlet
 */
public class MyQuestionsServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        QuestionDAO qdao=new QuestionDAO();
        AnswerDAO adao=new AnswerDAO();
        HttpSession session= request.getSession(false);
    	int emp_id=(int) session.getAttribute("id");
    	
        HashMap<Integer,Questions>hmap= qdao.getMyQuestions(emp_id);
        for(Entry<Integer, Questions> e:hmap.entrySet())
        {
        	
        	out.println("<p><b>"+e.getValue().getQuesDesc()+"</b></p><p>Category: "+e.getValue().getCategory().getCate_name()+" posted by: "
        	        	+e.getValue().getEmployee().getEmp_name()+"    Designation: "+e.getValue().getEmployee().getEmp_Designation()+"   Posted on: "+
        	        				e.getValue().getDate()+"</p>");
        	out.println("<a href='EditQuestion.jsp?id="+e.getKey()+"&desc="+e.getValue().getQuesDesc()+"'>Edit"+"</a>");
        	
        
        ArrayList<Answers> ansList=adao.getAnswers(e.getKey());
    	int a=e.getKey();
    	if(ansList==null)
    	{
    		out.println("<p><b>No Answers</b></p>");
    	}
    	
    	else
    	{
        	for(Answers ans:ansList)
        	{
        		out.println("<p style='color:#4169E1'>"+ans.getAnswer_desc()+" <br/></p><p>posted by: "
        	        	+ans.getEmp().getEmp_name()+"    Designation: "+ans.getEmp().getEmp_Designation()+"   Posted on: "+
        	        				ans.getDate()+"</p>");
        		
            	
        	} 
        	ansList=null;
    	}}
        
	}



}
