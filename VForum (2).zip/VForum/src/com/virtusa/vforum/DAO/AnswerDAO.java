package com.virtusa.vforum.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.ParseException;
import java.util.ArrayList;
import java.sql.Date;

import javax.servlet.http.HttpSession;

import com.virtusa.vforum.DBConnection.DBUtils;
import com.virtusa.vforum.models.Answers;
import com.virtusa.vforum.models.Category;
import com.virtusa.vforum.models.Employee;
import com.virtusa.vforum.models.Questions;
import com.virtusa.vfroum.queries.SqlQuery;

public class AnswerDAO {
   
	public ArrayList<Answers> getAnswers(int ques_id)
	{
		String sqlQuery=SqlQuery.getAnswers;//"select * from answers where ans_id=?";
		 ArrayList<Answers> list=new ArrayList<Answers>();
		try(Connection con=DBUtils.buildConnection();
				PreparedStatement pstmt=con.prepareStatement(sqlQuery);)
		{
			pstmt.setInt(1, ques_id);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()==false)
			{
				list=null;
			}
			else
			{
			do{
				 int ans_id=rs.getInt(1);
				 String ans_desc=rs.getString(2);
				 Date date=rs.getDate(3);
				 int emp_id=rs.getInt(4);
				 EmployeeDAO empdao=new EmployeeDAO();
				 Employee emp=empdao.getEmployee(emp_id);
				 
				 Answers ans=new Answers(ans_id,ans_desc,date,emp);
				 list.add(ans);
			}while(rs.next()) ;
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	public int addAnswer(int ansid,String answer,int empid) throws ParseException{
		String sqlQuery=SqlQuery.addAnswer;//"insert into answers values(?,?,?,?)";
		int count=0;
		try(Connection con=DBUtils.buildConnection();
				PreparedStatement pstmt=con.prepareStatement(sqlQuery);)
		{
			
			pstmt.setInt(1,ansid);
			pstmt.setString(2,answer);
			long milli=System.currentTimeMillis();
			Date date=new Date(milli);
			pstmt.setDate(3,date);
			pstmt.setInt(4,empid);
			
			//index starts from 1 and move rightwards
			count=pstmt.executeUpdate();
			
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return count;
	}
	public ArrayList<Answers> getMyAnswers(int emp_id)
	{
		String sqlQuery=SqlQuery.getMyAnswers;//"select * from answers where emp_id=?";
		 ArrayList<Answers> list=new ArrayList<Answers>();
		try(Connection con=DBUtils.buildConnection();
				PreparedStatement pstmt=con.prepareStatement(sqlQuery);)
		{
			pstmt.setInt(1, emp_id);
			ResultSet rs=pstmt.executeQuery();
			if(rs.next()==false)
			{
				list=null;
			}
			else
			{
			do{
				 int ans_id=rs.getInt(1);
				 String ans_desc=rs.getString(2);
				 Date date=rs.getDate(3);
				 int emp_id1=rs.getInt(4);
				 EmployeeDAO empdao=new EmployeeDAO();
				 Employee emp=empdao.getEmployee(emp_id1);
				 
				 Answers ans=new Answers(ans_id,ans_desc,date,emp);
				 list.add(ans);
			}while(rs.next()) ;
			 }
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return list;
	}
	public int deleteAnswerById(int qId)
	{
		String sqlQuery=SqlQuery.deleteAnswerById;//"delete from Answers where ans_id=?";
		int a=0;
		try(Connection con=DBUtils.buildConnection();
				PreparedStatement pstmt=con.prepareStatement(sqlQuery);)
		{
			 pstmt.setInt(1, qId);
			a=pstmt.executeUpdate();
		 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
	}
	public int deleteAnswerById(int qId,int eId)
	{
		String sqlQuery=SqlQuery.deleteAnswerById1;//"delete from Answers where ans_id=? and emp_id=?";
		int a=0;
		try(Connection con=DBUtils.buildConnection();
				PreparedStatement pstmt=con.prepareStatement(sqlQuery);)
		{
			 pstmt.setInt(1, qId);
			 pstmt.setInt(2, eId);
			a=pstmt.executeUpdate();
		 
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return a;
	}
}
