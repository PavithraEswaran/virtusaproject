package com.virtusa.dao;

import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;

import com.virtusa.model.Employee;

public class EmployeeDAOImpl implements EmployeeDAO {

	private SessionFactory sessionFactory;
	Session session = this.sessionFactory.openSession();
	Transaction tx = session.beginTransaction();
    public void setSessionFactory(SessionFactory sessionFactory) {
        this.sessionFactory = sessionFactory;
    }
    
	public void save(Employee e) {
		
		Transaction tx = session.beginTransaction();
		session.persist(e);
		tx.commit();
		session.close();
	}
	public void delete(Employee e) {
	session.delete(e);
	tx.commit();
	session.close();
	}
//	@SuppressWarnings("unchecked")
//	public List<Employee> list() {
//		
//		List<Employee> personList = session.createQuery("from Employee").list();
//		session.close();
//		return personList;
//	}

}
