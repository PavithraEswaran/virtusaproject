package com.virtusa.services;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;

import com.virtusa.dao.EmployeeDAO;
import com.virtusa.models.Employee;

public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeDAO edao;
	public void save(Employee e) {
		edao.save(e);

	}

	public void delete(Employee e) {
		edao.delete(e);

	}



}
