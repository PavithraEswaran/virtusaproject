package com.virtusa.vforum.testing;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.virtusa.vforum.DAO.RegistrationDAO;
import com.virtusa.vforum.models.Employee;



public class RegistrationJunit {

	
	@Test
	public void test() {
		RegistrationDAO rdao=new RegistrationDAO();
		boolean b=rdao.EmployeeIdCheck(8063704);
		boolean bo=rdao.EmployeeIdCheck(8063222);
	    assertTrue(bo);
	    assertFalse(b);
	    
	}
	@Test
	public void test1() {
		RegistrationDAO rdao=new RegistrationDAO();
		boolean b=rdao.UserNameCheck("pavi");
		boolean bo=rdao.UserNameCheck("kavi");
	    assertTrue(bo);
	    assertFalse(b);
	    
	}
	@Test
	public void test2() {
		RegistrationDAO rdao=new RegistrationDAO();
		Employee emp=new Employee(8063697,"Nivetha","Associate Engineer","Banglore","nivi","Nivetha@123");
		int count=rdao.register(emp);
	    Assert.assertEquals(1,count);
	    
	}

}
