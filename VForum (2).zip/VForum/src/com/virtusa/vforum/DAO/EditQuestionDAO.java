    package com.virtusa.vforum.DAO;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import com.virtusa.vforum.DBConnection.DBUtils;
import com.virtusa.vforum.models.Category;
import com.virtusa.vfroum.queries.SqlQuery;

public class EditQuestionDAO {
	public int updateQuestion(String newQuestion,int quesid){
		int count=0;
		 String sqlQuery=SqlQuery.updateQuestion;//"update questions set question_desc=? where ques_id=?";
		 try(Connection con=DBUtils.buildConnection();
					PreparedStatement pstmt=con.prepareStatement(sqlQuery);)
			{
			 pstmt.setString(1,newQuestion);
			 pstmt.setInt(2,quesid);
			  count=pstmt.executeUpdate();
			 
		 
				} catch (SQLException e) {
	// TODO Auto-generated catch block
						e.printStackTrace();
				}
		 return count;
	}
	}