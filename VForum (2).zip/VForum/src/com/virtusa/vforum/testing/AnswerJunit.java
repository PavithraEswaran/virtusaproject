package com.virtusa.vforum.testing;



import java.util.ArrayList;
import java.util.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;

import org.junit.Assert;
import org.junit.Assert.*;
import org.junit.Before;
import org.junit.Test;
import static org.hamcrest.CoreMatchers.*;
import com.virtusa.vforum.DAO.AnswerDAO;
import com.virtusa.vforum.models.Answers;
import com.virtusa.vforum.models.Employee;
import static org.junit.Assert.*;
//import static org.assertj.core.api.;

public class AnswerJunit {
	AnswerDAO adao=new AnswerDAO();
	ArrayList<Answers> list=new ArrayList<Answers>();
	ArrayList<Answers> listFalse=new ArrayList<Answers>();
	ArrayList<Answers> listExpected=new ArrayList<Answers>();
	ArrayList<Answers> anslist=new ArrayList<Answers>();
	Employee emp=null;
	//String date="2019-07-31";
	int count,deleteId,deleteIdQ,count1;
	//java.util.Date yourDate;
	@Before
	public void before(){
		list=adao.getAnswers(53);
		listFalse=adao.getAnswers(90);
		 emp=new Employee(8063704,"Kaviya","Associate Engineer","mumbai","kaviya","Kaviya@123");
				try{
			count=adao.addAnswer(52, "new answer", 8063704);
			//count1=adao.addAnswer(60, "add answer", 8063704);
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		anslist=adao.getMyAnswers(8063704);
		
	}
	@Test
	public void test() {
		
		//System.out.println(list.get(0).getAnswer_desc());
		//Assert.assertThat(list, is(listExpected));
		assertEquals(8063704,list.get(0).getEmp().getEmp_id());
		assertEquals(" Depends upon the project.,",list.get(0).getAnswer_desc());
		//junit.framework.Assert.assertThat(list.get(0).getDate()).hasMonth(7);
		Assert.assertEquals(null, listFalse);
		
	}

@Test
public void test1() {
	//Answer a
	assertEquals(" Depends upon the project.,",anslist.get(0).getAnswer_desc());
	
}
	@Test
	public void test2() {
		//Answer a
		Assert.assertEquals(1,count);
		
	}
	@Test
	public void test3() {
		Date  date = null;
		try {
			 date= new SimpleDateFormat("yyyy-MM-dd").parse("2019-07-29");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		Answers a=new Answers(50, "It is responsible for architecture, hardware, software and networking of computers", date, emp);
		deleteId=adao.deleteAnswerById(50);
		System.out.println(deleteId);
		Assert.assertEquals(1,deleteId);
		
	}
	@Test
	public void test4() {
		Date  date = null;
		try {
			 date= new SimpleDateFormat("yyyy-MM-dd").parse("2019-07-29");
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		Answers a=new Answers(53, " Depends upon the project.,", date, emp);
		deleteIdQ=adao.deleteAnswerById(53,8063704);
		System.out.println(deleteIdQ);
		Assert.assertEquals(1,deleteIdQ);
		
	}

}
