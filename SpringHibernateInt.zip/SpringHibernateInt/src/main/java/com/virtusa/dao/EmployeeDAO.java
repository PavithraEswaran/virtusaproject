package com.virtusa.dao;

import java.util.List;


import com.virtusa.model.Employee;

public interface EmployeeDAO {

	public void save(Employee e);
	public void delete(Employee e);
	//public List<Employee> list();
	
}
