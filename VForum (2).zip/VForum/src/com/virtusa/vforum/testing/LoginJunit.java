package com.virtusa.vforum.testing;

import static org.junit.Assert.*;

import org.junit.Assert;
import org.junit.Test;

import com.virtusa.vforum.DAO.EmployeeDAO;
import com.virtusa.vforum.models.Employee;

public class LoginJunit {

	@Test
	public void logintest() {
		EmployeeDAO edao=new EmployeeDAO();
		Employee emp=edao.getEmployee(8063703);
		Employee empTest=new Employee(8063703,"Pavithra","Associate Engineer","Banglore","pavi","Pavithra@123");
		Assert.assertEquals(empTest.getEmp_name(),emp.getEmp_name());
		Assert.assertEquals(empTest.getEmp_Designation(),emp.getEmp_Designation());
		Assert.assertEquals(empTest.getEmp_Location(),emp.getEmp_Location());
		Assert.assertEquals(empTest.getUser_name(),emp.getUser_name());
		Assert.assertEquals(empTest.getPassword(),emp.getPassword());
	}

}
