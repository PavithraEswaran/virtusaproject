package com.virtusa.vforum.controllers;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.virtusa.vforum.DAO.AnswerDAO;
import com.virtusa.vforum.DAO.CategoryDAO;
import com.virtusa.vforum.DAO.QuestionDAO;
import com.virtusa.vforum.models.Answers;
import com.virtusa.vforum.models.Category;
import com.virtusa.vforum.models.Questions;

/**
 * Servlet implementation class TechServlet
 */
public class TechServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session= request.getSession(false);
    	int emp_id=(int) session.getAttribute("id");
    	response.setContentType("text/html");
        PrintWriter out=response.getWriter();
        out.println("<a href='TechnicalPage.jsp'>Click here to add question</a>");
        out.println("<br/>");
        //String question=request.getParameter("question");
        CategoryDAO cdao=new CategoryDAO();
        Category c=cdao.getCategory("TECHNICAL");
       
        QuestionDAO qdao=new QuestionDAO();
        
        AnswerDAO adao=new AnswerDAO();
        HashMap<Integer,Questions>hmap= qdao.getQuestions(c);
        
        for(Entry<Integer, Questions> e:hmap.entrySet())
        {
        	//out.println("<h3>"+e.getKey()+"  "+e.getValue().getQuesDesc()+"  "+e.getValue().getEmployee().getEmp_name()+
        		//	"  "+e.getValue().getDate()+"</h3>");
        	out.println("<p><b>"+e.getValue().getQuesDesc()+"</b><br/>posted by:"+e.getValue().getEmployee().getEmp_name()+" &nbsp;&nbsp;&nbsp;  Designation: "
        			+e.getValue().getEmployee().getEmp_Designation()+"   &nbsp;&nbsp;&nbsp;  Posted on: "+e.getValue().getDate()+"</p>");
      	ArrayList<Answers> ansList=adao.getAnswers(e.getKey());
        	int a=e.getKey();
        	if(ansList==null)
        	{
        		out.println("<p><b>No Answers</b></p>");
        	}
        	
        	else
        	{out.println("<p><b>Answers</b></p>");
	        	for(Answers ans:ansList)
	        	{
	        		out.println("<p style='color:#4169E1'>"+ans.getAnswer_desc()+" <br/></p><p>posted by: "
	        	        	+ans.getEmp().getEmp_name()+"    Designation: "+ans.getEmp().getEmp_Designation()+"   Posted on: "+
	        	        				ans.getDate()+"</p>");
	        		
	            	
	        	} 
	        	ansList=null;
        	}
        	if(emp_id!=e.getValue().getEmployee().getEmp_id())
	        out.println("<a href='TechAddAnswer.jsp?postId="+e.getKey()+"&desc="+e.getValue().getQuesDesc()+"'>Click here to add Answer"+"</a>");
	        	
        }
        
        
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
